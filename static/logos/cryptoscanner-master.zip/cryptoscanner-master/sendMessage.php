<?php
/**
 * Created by PhpStorm.
 * User: viacheslav
 * Date: 3/10/18
 * Time: 11:39
 */

if (!empty($_POST)) {
    $errors = [];

    if (!isset($_POST['name'])) {
        $errors[] = 'name';
    }

    if (!isset($_POST['email']) || !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'email';
    }

    if (!isset($_POST['subject'])) {
        $errors[] = 'subject';
    }

    if (!isset($_POST['message'])) {
        $errors[] = 'message';
    }

    if (empty($errors)) {
     $query= htmlentities($_POST['message']);
        $to = 'danial@cryptoscanner.co';
      //  $to = 'danialheng@gmail.com';
        $subject ="Query received at cryptoscanner.co";
        $from = 'danial@cryptoscanner.co';
      
$message = "
<html>
<head>
<title>HTML email</title>
</head>
<body>
Hi,<br/>
Below mentioned details have been received on http://cryptoscanner.co<br/>

<table>
<tr>
<td>Name: $from</td>
</tr><tr>
<td>Email: $email</td>
</tr><tr>
<td>Subject: $subject</td>
</tr><tr>
<td>Query: ".$query."</td>
</tr>
</table>
<br/>
Thanks,<br/>
Danial<br/>
cryptoscanner.co 
<br/>
</body>
</html>
";

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
$headers .= 'From: <'.$from.'>' . "\r\n";
if(mail($to,$subject,$message,$headers)){
  //  $errors[]="sent";
}
         
        
    }

    header('Content-type: application/json');
    echo json_encode(array('errors' => $errors));
    exit;
}
