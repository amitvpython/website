<?php
//D:\wamp\bin\php\php5.6.25\php.exe -e "D:\wamp\www\cryptoscanner\test.php"
ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

//print_r(phpinfo());

include_once 'ccxt.php';



$data = array(
    'db_host'				    => 'localhost',
   // 'db_base'				    => 'crypto',
   'db_base'				    => 'prices',
    'db_user'				    => 'root',
   // 'db_pass'				    => '',
    'db_pass'				    => 'NON4242(&&$2@@#342',

);
$mysqli = new mysqli($data['db_host'], $data['db_user'], $data['db_pass'], $data['db_base']);
$mysqli->set_charset('utf8');



function insertOrUpdate($table, $data, $update_data = false){
global $mysqli;
    $fields = array();
    $values = array();
    $set    = array();

    if (is_array($data)){

        foreach ($data as $field => $value){

            $value = "'{$value}'";

            $fields[] = "`$field`";
            $values[] = $value;

            if($update_data === false){
                $set[] = "`{$field}` = {$value}";
            }

        }

        $fields = implode(', ', $fields);
        $values = implode(', ', $values);

        $sql = "INSERT INTO {$table} ({$fields})\nVALUES ({$values})";

        if(is_array($update_data)){
            foreach ($update_data as $field=>$value) {

                $value = $value = "'{$value}'";

                $set[] = "`{$field}` = {$value}";

            }
        }

        $set = implode(', ', $set);

        $sql .= " ON DUPLICATE KEY UPDATE {$set}";

		//echo $sql.'<br/>';
		

         $mysqli->query($sql);

    }

    return false;

}

function addPrice($data){
    insertOrUpdate('v28_crypto_ticker',$data, array('bid'=>$data['bid'],'ask'=>$data['ask'],'price'=>$data['price']));
}

        date_default_timezone_set ('UTC');
        $exchanges = \ccxt\Exchange::$exchanges;
        $i = 0;
		$exchange = 'hitbtc2';
            $id = "\\ccxt\\".$exchange;
            echo $exchange;
            try {
                $exchange = new $id();
                echo "--------------------------------------------\n".PHP_EOL;
                echo $exchange->id . "\n".PHP_EOL;
                $tickers = $exchange->fetch_tickers();
				
                foreach ($tickers as $ticker){
                  
                    if(isset($ticker['symbol']))
                    {
						$arr = explode('/',$ticker['symbol']);
	                    addPrice(array(
	                        'exchange'=>$exchange->id,
	                        'symbol' => $ticker['symbol'],
	                        'base'=>$arr[0],
	                        'quote'=>$arr[1],
	                        'bid' =>$ticker['bid'],
	                        'ask' =>$ticker['ask'],
	                        'price' =>$ticker['last']
	                    ));
					}
                    
                }

            } catch (\ccxt\RequestTimeout $e) {
                echo '[Timeout Error] ' . $e->getMessage () . ' (ignoring)' . "\n";
            } catch (\ccxt\DDoSProtection $e) {
                echo '[DDoS Protection Error] ' . $e->getMessage () . ' (ignoring)' . "\n";
            } catch (\ccxt\AuthenticationError $e) {
                echo '[Authentication Error] ' . $e->getMessage () . ' (ignoring)' . "\n";
            } catch (\ccxt\ExchangeNotAvailable $e) {
                echo '[Exchange Not Available] ' . $e->getMessage () . ' (ignoring)' . "\n";
            } catch (\ccxt\NotSupported $e) {
                echo '[Not Supported] ' . $e->getMessage () . ' (ignoring)' . "\n";


                try {

                    $markets = $exchange->fetch_markets();
                    print_r($markets);
                    exit;
                    foreach($markets as $market){
                        $ticker = $exchange->fetch_ticker($market['symbol']);
                        echo '$market === ===';
                        print_r($market);
                        $arr = explode('/',$ticker['symbol']);
                        echo '$ticker === ===';
                        print_r($ticker);
                        addPrice(array(
                            'exchange'=>$exchange->id,
                            'symbol' => $ticker['symbol'],
                            'base'=>$arr[0],
                            'quote'=>$arr[1],
                            'bid' =>$ticker['bid'],
                            'ask' =>$ticker['ask'],
                            'price' =>$ticker['last']
                        ));
                    }
                } catch (Exception $e) {
                    echo '[Error] ' . $e->getMessage () . "\n";
                }





            } catch (\ccxt\NetworkError $e) {
                echo '[Network Error] ' . $e->getMessage () . ' (ignoring)' . "\n";
            } catch (\ccxt\ExchangeError $e) {
                echo '[Exchange Error] ' . $e->getMessage () . ' (ignoring)' . "\n";
            } catch (Exception $e) {
                echo '[Error] ' . $e->getMessage () . "\n";
            }
            echo "\n";
            
          
      
