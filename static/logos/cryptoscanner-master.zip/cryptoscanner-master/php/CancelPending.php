<?php

namespace ccxt;

class CancelPending extends InvalidOrder {

}