<?php

namespace ccxt;

class ExchangeNotAvailable extends NetworkError {

}