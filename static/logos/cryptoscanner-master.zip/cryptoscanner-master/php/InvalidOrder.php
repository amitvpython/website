<?php

namespace ccxt;

class InvalidOrder extends ExchangeError {

}