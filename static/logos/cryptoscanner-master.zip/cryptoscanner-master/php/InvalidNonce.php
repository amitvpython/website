<?php

namespace ccxt;

class InvalidNonce extends ExchangeError {

}