<?php

namespace ccxt;

class NotSupported extends ExchangeError {

}