<?php

namespace ccxt;

class OrderNotFound extends InvalidOrder {

}