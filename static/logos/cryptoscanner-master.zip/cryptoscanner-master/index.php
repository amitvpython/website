<?php
/**
 * Date: 23.01.18
 * Time: 14:00
 */

//$crypto = $_GET['crypto'];

ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

$base = isset($_GET['base']) ? $_GET['base'] : 'BTC';
$quote = isset($_GET['quote']) ? $_GET['quote'] : 'USD';

function getTheBest(){

    $base = isset($_GET['base']) ? $_GET['base'] : 'BTC';
    $quote = isset($_GET['quote']) ? $_GET['quote'] : 'USD';

    $sql = "SELECT exchange, price,base, quote FROM `v28_crypto_ticker` WHERE `base` = '".$base."' and `quote` = '".$quote."' and price <> 0 and price is not NULL order by `price` asc limit 10 ";
    $data = array(
        'db_host'				    => 'localhost',
        'db_base'				    => 'prices',
        'db_user'				    => 'root',
        'db_pass'				    => 'NON4242(&&$2@@#342',
//        'db_host'				    => 'localhost',
//        'db_base'				    => 'crypto',
//        'db_user'				    => 'root',
//        'db_pass'				    => '',
    );

    
    $mysqli = new mysqli($data['db_host'], $data['db_user'], $data['db_pass'], $data['db_base']);
    $mysqli->set_charset('utf8');

    $result = $mysqli->query($sql);

    $data = array();
    while ($item = $result->fetch_assoc()) {
        $data[] = array(
                'base'=>strtolower($item['base']),
                'quote'=>strtolower($item['quote']),
                'exchange'=>$item['exchange'],
                'price'=>$item['price']
        );
    }
    return $data;
}


function getSymbols(){

    $sql = "SELECT base, quote, count(id) FROM `v28_crypto_ticker` WHERE exchange <> ' coinmarketcap' and price <> 0 and price is not NULL GROUP BY base, quote HAVING count(id)>4 limit 100 ";
    $data = array(
        'db_host'				    => 'localhost',
        'db_base'				    => 'prices',
        'db_user'				    => 'root',
        'db_pass'				    => 'NON4242(&&$2@@#342',
//        'db_host'				    => 'localhost',
//        'db_base'				    => 'crypto',
//        'db_user'				    => 'root',
//        'db_pass'				    => '',
    );

    $mysqli = new mysqli($data['db_host'], $data['db_user'], $data['db_pass'], $data['db_base']);
    $mysqli->set_charset('utf8');

    $result = $mysqli->query($sql);

    $data = array();
    while ($item = $result->fetch_assoc()) {
        if (!$item['base']){continue;}
        $data[] = $item;

    }
    return $data;

}

$items = getTheBest();

$pairs = getSymbols();

?>

<?php
    require_once 'getData.php';
?>

<html>
<head>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-115499767-1"></script>
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'UA-115499767-1');
    </script>

    <!-- Google Tag Manager -->
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-WFQQN3H');</script>
    <!-- End Google Tag Manager -->

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

    <title>Cryptoscanner | Altcoin Bitcoin Price | Scan The Cheapest Cryptocurrency Rates</title>
    
    <meta name="title" content="Cryptoscanner | Altcoin Bitcoin Price | Scan The Cheapest Cryptocurrency Rates">
    <meta name="description" content="Cryptoscanner scans & compares for the cheapest cryptocurrency rates on the internet. Over 300 cryptocurrencies from more than a 120 exchanges with one click of a button. Free, fast and easy!">
    <meta name="keywords" content="Cryptocurrency, Binance, coinbase, coinmarketcap, cheap cryptocurrency rates, cheap bitcoin, cheap ethereum, bitcoin, ethereum, tron, bitcoin price, bittrex, good cryptocurrency rates">

    <!-- Favicons -->
    <link rel="shortcut icon" href="/favicon/favicon.ico" type="image/png">
    <link rel="apple-touch-icon" sizes="57x57" href="/favicon/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="/favicon/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/favicon/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="/favicon/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/favicon/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="/favicon/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/favicon/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/favicon/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/favicon/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192"  href="/favicon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="/favicon/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon/favicon-16x16.png">
    <link rel="manifest" href="/favicon/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="/favicon/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
    
    <!-- Facebook -->
    <meta property="og:title" content="CryptoScanner | Scan The Cheapest Cryptocurrency Rates" />
    <meta property="og:type" content="article" />
    <meta property="og:image" content="http://cryptoscanner.co/images/coverpage.png" />
    <meta property="og:image:width" content="1200" />
    <meta property="og:image:height" content="627" />
    <meta property="fb:app_id" content="179259906198627" />
    <meta property="og:url" content="http://www.cryptoscanner.co/" />
    <meta property="og:description" content="Scans and compares for the cheapest cryptocurrency rates on the internet. Over 300 cryptocurrencies from more than a 120 exchanges with one click of a button. Free, fast and easy!" />



    <!-- Facebook Pixel Code -->
    <script>
        
        
        
    !function(f,b,e,v,n,t,s)
    {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
    n.callMethod.apply(n,arguments):n.queue.push(arguments)};
    if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
    n.queue=[];t=b.createElement(e);t.async=!0;
    t.src=v;s=b.getElementsByTagName(e)[0];
    s.parentNode.insertBefore(t,s)}(window,document,'script',
    'https://connect.facebook.net/en_US/fbevents.js');
     fbq('init', '1510748119232952'); 
    fbq('track', 'PageView');
    </script>
    <noscript>
     <img height="1" width="1" 
    src="https://www.facebook.com/tr?id=1510748119232952&ev=PageView
    &noscript=1"/>
    </noscript>
    <!-- End Facebook Pixel Code -->

    <!-- For Twitter -->
    <meta name="twitter:title" content="CryptoScanner | Scan The Cheapest Cryptocurrency Rates" />
    <meta name="twitter:description" content="Scans and compares for the cheapest cryptocurrency rates on the internet. Over 300 cryptocurrencies from more than a 120 exchanges with one click of a button. Free, fast and easy!" />
    <meta name="twitter:image" content="http://cryptoscanner.co/images/big.png" />

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,500,700" rel="stylesheet">
    
    <!-- CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="css/main.css?ver=21">

    <!-- Javascript -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/list.js/1.5.0/list.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/socket.io/2.0.3/socket.io.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <!-- Icons -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
    
        <script>
$(document).ready(function(){
    $(document).ajaxStart(function(){
        $("#wait").css("display", "block");
    });
    $(document).ajaxComplete(function(){
        $("#wait").css("display", "none");
    });
   
});
</script>


</head>
<body>

    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WFQQN3H"
    height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <div id="wait" style="display:none;position:absolute;top:50%;left:50%;padding:2px;"><img src='images/demo_wait.gif' width="64" height="64" /><br>Loading..</div>
    
    <div id="blueheader" > 
        <header>
            <div class="container-fluid">
                <nav class="navbar navbar-expand-md">
                    <a href="http://cryptoscanner.co/" class="navbar-brand">
                        <img src="images/cryptowhite.png" alt=cryptoscanner"">
                    </a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon">
                            <i class="fas fa-bars"></i>
                        </span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-end" id="navbarsExampleDefault">
                        <ul class="navbar-nav">
                            <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                            <li class="nav-item"><a class="nav-link" href="#feature-request-id">Feature Request</a></li>
                            <li class="nav-item"><a class="nav-link link-border" href="http://cryptoscanner.co/coming-soon">How To Make Money From Cryptocurrency?</a></li>
                        </ul>
                    </div>
                </nav>
            </div>
        </header>
        <section id="sw-segment" class="section-price">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 offset-md-2">
                        <h2 class="text-center">The Smartest Cryptocurrency Price Search Engine On Planet Earth</h2>
                        <div class="row">
                            <div class="col-md-6 offset-md-3">
                                <p class="text-center">Scan for the cheapest cryptocurrency rates on the internet. Over 300 cryptocurrencies from more than 120 exchanges with one click of a button. ⚡</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="ui centered container">
                <form action="" id="form-scan">
                    <div class="row currency-selector">
                        <div class="ui big right labeled input currency-dropdown">
                            <div class="ui basic label">I have</div>
                            <input type="text" placeholder="Amount" name="amount" id="amount" value="1" >
                            <select class="custom-select d-block " name="from_currency" id="from_currency" disabled required>
                                <option value="">Select Currency</option>
                            </select>
                        </div>
                        <button id="sw-exchange" class="ui inverted button exchange-currencies" role="button">
                            <img src="images/switch.png" id="sw-switch">
                        </button>
                        <div class="ui big right labeled input currency-dropdown">
                            <div class="ui basic label">I want</div>
                            <input type="text" placeholder="" name="txt_you_get" id="txt_you_get" value="" >
                            <select class="custom-select d-block" name="to_currency" id="to_currency" disabled required>
                                <option value="">Select Currency</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <p class="text-center" style="margin:40px 0 20px"><button type="submit" class="btn btn-primary btn_calc">Scan exchanges</button></p>
                        </div>
                        <div class="col-md-12">
                            <p class="text-center"><font color="white"> *Prices do not include exchange fees.</font></p>
                        </div>
                    </div>
                </form>
            </div>

            <!-- <h1><?php echo $base.'/'.$quote; ?></h1>
            <div id="cryptolist">
                <ul class="list">
                    <?php foreach ($items as $item) {?>
                        <li>
                            <span class="value" id="<?php echo $item['exchange'].'_'.strtolower($item['base']).'_'.strtolower($item['quote']);?>"><?php echo $item['price'];?></span>
                            <span class="exchange"><?php echo $item['exchange'];?></span>
                        </li>
                    <?php } ?>
                </ul>
            </div>
            <ul>
                <?php foreach ($pairs as $pair) {?>
                    <li>
                        <a href="index.php?base=<?php echo $pair['base'];?>&quote=<?php echo $pair['quote'];?>"><?php echo $pair['base'].'/'.$pair['quote'];?></a>
                    </li>
                <?php } ?>
            </ul> -->
        </section>
    </div>
    
    
<!--                <table class="table table-sm" id="price-table" style="display: none">
                <thead>
                    <tr>
                        <th scope="col" class="text-right">#</th>
                        <th scope="col">Source</th>
                        <th scope="col">Pair</th>
                        <th scope="col" class="text-right">Price</th>
                        <th scope="col" class="text-right">You Get</th>
                    </tr>
                </thead>
                <tbody>

                </tbody>
            </table>-->
    
    
        <section class="recent-transactions">    

            
            <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <!--<h2 class="text-center">Recent Transactions</h2>-->
                    <table class="table table-striped table-sm" id="price-table" style="display: none">
                        <thead>
                            <tr>
                                <th scope="col" >Pair</th>
                                <th class="exchange" scope="col">Exchange</th>
                                <th scope="col" >Price</th>
                                <th scope="col">You Get</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                    <div class="row no_data" style="display: none">
                        <div class="col-md-12">
                            <p class="text-center">No currency or exchange.</p>
                        </div>
                    </div>
                    <div class="row" id='pagination' style="display:none">
                        <div class="col-md-6">
                            <nav aria-label="Page navigation price-navigation">
                                <ul class="pagination"></ul>
                            </nav>
                        </div>
                        <div class="col-md-6">
                            <p class="text-right"><a href="#feature-request-id" style="color:#666">Can't see your currency or exchange?</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    
    
            <div class="row no_data" style="display: none">
                <div class="col-md-12">
                    <p class="text-center">No currency or exchange.</p>
                </div>
            </div>
            <div class="row" id='pagination' style="display:none">
                <div class="col-md-6">
                    <nav aria-label="Page navigation price-navigation">
                        <ul class="pagination"></ul>
                    </nav>
                </div>
                <div class="col-md-6">
                    <p class="text-right"><a href="#feature-request-id" style="color:#666">Can't see your currency or exchange?</a></p>
                </div>
            </div>

    
    </section>

    <section>
        <div id="feature-request-id">
            <div class="container feature-request">
                <div class="row">
                    <div class="col-md-8 offset-md-2">
                        <h4 class="text-center">Feature Request</h4>
                        <p class="text-center">Want us to feature your Currency or Exchange? Have a feature you'd like to see?</p>
                        <form action="#">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="name" name="name" placeholder="Your Name">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <input type="email" class="form-control"  id="email"  name="email" placeholder="Your Email">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="subject" name="subject" placeholder="Your Subject">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <textarea class="form-control" id="message"  name="message"  rows="5" placeholder="Message"></textarea>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <div class="row">
                            <div class="col-md-12">
                                <p class="text-center"><button type="submit" class="btn btn-primary send_message">Submit</button></p>
                            </div>
                        </div>
                        <p class="text-center text_sending_message" style="display: none">       
                            <font color="green"> <b> Message sent successfully</b></font>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-10 offset-md-1">
                    <div class="row">
                        <div class="col-md-5">
                            <img src="images/crypto-small.jpg" alt=cryptoscanner"" class="logo" />
                            <p>Cryptoscanner scans the internet from over a 120 exchanges with over 300 cryptocurrencies for the best and cheapest rates in one click of a button. Ranging from Bitcoin price to Altcoin price, Comparing bitcoin price and altcoins price is now made easy. </p>
                            <ul class="social">
                                <li><a href="https://www.facebook.com/cryptoscanner.co/"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="https://twitter.com/Cryptoscannerco"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="https://www.instagram.com/cryptoscanner.co/"><i class="fab fa-instagram"></i></a></li>
                            </ul>
                        </div>
                        <div class="col-md-4 offset-md-3">
                            <h4>Contact Us</h4>
                            <ul class="contact">
                                <li><a href="#"><span class="icon"><i class="fas fa-envelope"></i></span> danial@cryptoscanner.co</a></li>
                                <li><a href="#"><span class="icon"><i class="fas fa-globe"></i></span> cryptoscanner.co</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="copyright">Cryptoscanner © <?=date('Y');?>. All Rights Reserved</div>
                </div>
            </div>
        </div>
    </footer>


<script type="text/javascript">
    
    function round(value, decimals) {
        return Number(Math.round(value +'e'+ decimals) +'e-'+ decimals).toFixed(decimals);
    }


    $(function() {
        $('select').select2();

        $('input').on('click', function(e) {
            $(e.currentTarget).removeClass('error-input');
        });

        $('.select2-selection').on('click', function(e) {
            $(e.currentTarget).parents('.select2').removeClass('error-input');
        });

        $('.send_message').on('click', function() {
            $('.text_sending_message').hide();
            var objectName = $('#name');
            var objectEmail = $('#email');
            var objectSubject = $('#subject');
            var objectMessage = $('#message');

            objectName.removeClass('error-input');
            objectEmail.removeClass('error-input');
            objectSubject.removeClass('error-input');
            objectMessage.removeClass('error-input');

            var name = objectName.val();
            var email = objectEmail.val();
            var subject = objectSubject.val();
            var message = objectMessage.val();

            if (!name) {
                objectName.addClass('error-input');
            }

            if (!email) {
                objectEmail.addClass('error-input');
            }

            if (!subject) {
                objectSubject.addClass('error-input');
            }

            if (!message) {
                objectMessage.addClass('error-input');
            }

            if (!name || !email || !subject || !message) {
                return false;
            }

            $.post('sendMessage.php', {name: name, email: email, subject: subject, message: message}, function (data) {

                var countErrors = data.errors.length;
                if (countErrors) {
                    for (var i = 0; i < countErrors; i++) {
                        $('#' + data.errors[i]).addClass('error-input');
                    }
                } else {
                    $('.text_sending_message').show();
                    objectName.val('');
                    objectEmail.val('');
                    objectSubject.val('');
                    objectMessage.val('');
                }
            });

        });
    });

    var socket = io.connect('https://coincap.io');

    <?php if ($quote == 'USD' or $quote == 'USDT') { ?>
        socket.on('trades', function (data) {
            updateMarkets(data);
        });
    <?php }?>

    var options = {valueNames: ['value', 'exchange']};

    var crList = {};

    window.updateMarkets = function (data) {
        if (data.coin != undefined) {
            var coin = data.coin;

            if (data.coin == "<?php echo strtoupper($base);?>") {
                sel = $('#' + data.exchange_id + '_<?php echo strtolower($base).'_'.strtolower($quote);?>');

                if (sel.length) {
                    sel.html(data.msg.price);
                    crList = new List('cryptolist', options);
//                    crList.sort('value', {order: "asc", sortFunction:function (a, b) {
//                        return Number(a)>Number(b)
//                    }} );
                }
            }
            price = data.msg.price;
        }

    };


    function update() {

        $.getJSON('update.php',{base:'<?php echo $base;?>',quote:'<?php echo $quote;?>'}, function (data) {

            $(".list li").each(function(index, value) {
                $(this).addClass('remove');
            });

            for (var i in data) {
                var row = data[i];
                id = row.exchange + '_'+row.base+'_'+row.quote;
                sel = $('#' + row.exchange + '_'+row.base+'_'+row.quote);
                if (sel.length){
                    sel.html(row.price).parent().removeClass('remove');
                } else {
                    $('.list').append(' <li><span class="value" id="'+id+'">'+row.price+'</span><span class="exchange">'+row.exchange+'</span></li>');
                }

            }
            $(".remove").each(function(index, value) {
                $(this).remove();
            });
            crList = new List('cryptolist', options);
//            crList.sort('value', {order: "asc", sortFunction:function (a, b) {
//                return Number(a)>Number(b)
//            }} );
        });

    }

    update();




    $.post('getData.php', {type: 'getAllCurrencyNames'}, function (data) {
        if (data.result) {
            var objectTo = $('#to_currency');
            var objectFrom = $('#from_currency');
            var result = data.result;
            var countResult = result.length;

            for (var i = 0; i < countResult; i++) {
                var currentValue = result[i];
                if (currentValue && currentValue != null) {
                    objectTo.append('<option value="'+ currentValue.id +'">' + currentValue.name + '</option>');
                    objectFrom.append('<option value="'+ currentValue.id +'">' + currentValue.name + '</option>');
                }
            }
            objectTo.removeAttr('disabled');
            objectFrom.removeAttr('disabled');
        }
        $('select').select2();
    });

    var countInOnePage = 10;
    var countShowPages = 3;
    var countPages = 0;
    var currentPage;
    var result;
    var resultCount;
    var amount;

    $('.btn_calc').on('click', function(event) {
        amount = $('#amount').val();
        var toCurrency = $('#to_currency').val();
        var fromCurrency = $('#from_currency').val();

        if (!amount) {
            $('#amount').addClass('error-input');
        }

        if (!toCurrency) {
            $('#to_currency').parent().find('.select2').addClass('error-input');

        }

        if (!fromCurrency) {
            $('#from_currency').parent().find('.select2').addClass('error-input');

        }

        if (toCurrency == fromCurrency) {
            $('#to_currency').parent().find('.select2').addClass('error-input');
            $('#from_currency').parent().find('.select2').addClass('error-input');
        }

        if (amount && toCurrency && fromCurrency && toCurrency != fromCurrency) {
            //facebook pixel event track
            fbq('trackCustom', 'searchexchanges', {from_currency: fromCurrency, from_amount: amount, to_currency: toCurrency});
            $.post('getData.php', {type: 'calc', amount: amount, toCurrency: toCurrency, fromCurrency: fromCurrency}, function (data) {
                if (resultCount = data.result.length) {
                    result = data.result;
                    currentPage = 1;

                    if (resultCount > countInOnePage) {
                        countPages = Math.ceil(resultCount / countInOnePage);
                        renderPagination();
                    } else {
                        $('#pagination').hide();
                    }

                    $('.no_data').hide();

                    renderData();
                } else {
                    $('.no_data').show();
                    $('#price-table').hide();
                    $('#pagination').hide();
                }
            });

            $('#to_currency').parent().find('.select2').removeClass('error-input');
            $('#from_currency').parent().find('.select2').removeClass('error-input');
        }

        return false;
    });

    $('textarea').on('click', function(e) {
        $(e.currentTarget).removeClass('error-input');
    });
    
    $('#price-table').on('click', '.btn-toggle-exchange', function(event) {
    	
    	$(this).next('.exchange-details').toggle();
    	
    });

    function renderPagination() {
        var minPage, maxPage;

        if (currentPage == 1) {
            minPage = 1;
            maxPage = countShowPages;
        } else if (currentPage == countPages) {
            minPage = countPages - countShowPages * 1 + 1;

            if (minPage <= 0) {
                minPage = 1;
            }

            maxPage = countPages;
        } else {
            minPage = currentPage * 1 - 1;
            maxPage = currentPage * 1 + 1;
        }

        $('#pagination').show();
        var paginationHtml = '<li class="page-item"><a class="page-link" href="1"><</a></li>';

        for (var i = minPage; i <= maxPage; i++) {
            var active = '';

            if (i == currentPage) {
                active = 'active';
            }
            paginationHtml += '<li class="page-item '+ active +'"><a class="page-link active" href="'+ i +'">' + i + '</a></li>'
        }

        paginationHtml += '<li class="page-item"><a class="page-link" href="'+ countPages +'">></a></li>';

        $('.pagination').html(paginationHtml);
        $('.page-item').on('click', clickPage);
    }

    function clickPage(e) {
        var page = $(e.currentTarget).find('a').attr('href');

        if (page != currentPage) {
            currentPage = page;
            renderPagination();
            renderData();
        }

        return false;
    }

    function renderData() {
        $('#price-table').show();

        var html = '';
        var start = (currentPage - 1) * countInOnePage;
        var end = start + countInOnePage;

        if (resultCount < end) {
            end = resultCount;
        }
        var company1;
        var link1;
        var company2;
        var link2;
        for (var i = start; i < end; i++) {
            var id = '';
            var border = 'style="border-top: none"';
            var countConversion = result[i].conversion.length;
            if (countConversion == 2) 
            {
                 
                 company1 = result[i].conversion[0].company;
                 company1 = company1.toLowerCase();
                 if(company1 == "bitfinex2")
                 {
				 	company1 = "bitfinex";
				 }
				  if(company2 == "bitfinex2")
                 {
				 	company2 = "bitfinex";
				 }
                 
                if(company1=="binance"){
                 link1="https://www.binance.com/?ref=11303298";
                }
                else if(company1=="cryptopia"){
                 link1="https://www.cryptopia.co.nz/Register?referrer=dantheman28";
                }
                else if(company1=="hitbtc"){
                 link1="https://hitbtc.com/?ref_id=5aa5459e4d0d5";
                }
                else if(company1=="livecoin"){
                 link1="https://livecoin.net/?from=Livecoin-df63826Z";
                }
                else if(company1=="lakebtc"){
                 link1="https://www.lakebtc.com/?ref=blortu";
                }
                else if(company1=="vaultoro"){
                 link1="https://www.vaultoro.com/?a=109258";
                }
                else if(company1=="bitbay"){
                 link1="http://bitbay.net";
                }
                else if(company1=="liqui"){
                 link1="http://liqui.io";
                }
                else if(company1=="dsx"){
                 link1="http://dsx.uk";
                }
                else if(company1=="wex"){
                 link1="http://wex.nz";
                }
                else if(company1=="getbtc"){
                 link1="http://getbtc.org";
                }
                else if(company1=="gate"){
                 link1="http://gate.io";
                }
                else if(company1=="c-cex"){
                 link1="http://c-cex.com";
                }
                else if(company1=="acx"){
                 link1="http://acx.io";
                }
                 else if(company1=="okcoin"){
                 link1="https://www.okcoin.com";
                }
                else if(company1=="kucoin"){
                 link1="https://www.kucoin.com/#/?r=MQJ3fR";
                }
                else {
                   link1="http://"+company1+".com";  
                }
                


                 company2 = result[i].conversion[1].company;
                 company2 = company2.toLowerCase();
                 
                if(company2=="binance"){
                 link2="https://www.binance.com/?ref=11303298";
                }
                else if(company2=="cryptopia"){
                 link2="https://www.cryptopia.co.nz/Register?referrer=dantheman28";
                }
                else if(company2=="hitbtc"){
                 link2="https://hitbtc.com/?ref_id=5aa5459e4d0d5";
                }
                else if(company2=="livecoin"){
                 link2="https://livecoin.net/?from=Livecoin-df63826Z";
                }
                else if(company2=="lakebtc"){
                 link2="https://www.lakebtc.com/?ref=blortu";
                }
                else if(company2=="vaultoro"){
                 link2="https://www.vaultoro.com/?a=109258";
                }
                 else if(company2=="bitbay"){
                 link2="http://bitbay.net";
                }
                else if(company2=="liqui"){
                 link2="http://liqui.io";
                }
                else if(company2=="dsx"){
                 link2="http://dsx.uk";
                }
                else if(company2=="wex"){
                 link2="http://wex.nz";
                }
                else if(company2=="getbtc"){
                 link2="http://getbtc.org";
                }
                else if(company2=="gate"){
                 link2="http://gate.io";
                }
                else if(company2=="c-cex"){
                 link2="http://c-cex.com";
                }
                 else if(company2=="acx"){
                 link2="http://acx.io";
                }
                 else if(company2=="okcoin"){
                 link2="https://www.okcoin.com";
                }
                else if(company2=="kucoin"){
                 link2="https://www.kucoin.com/#/?r=MQJ3fR";
                }
                else {
                   link2="http://"+company2+".com"; 
                }

				if(i == start)
				{
					$('#txt_you_get').val(result[i].conversion[1].unit_get);
				}

                 html +=
                    '<tr>' +
                    '<td><a href="#">' + result[i].conversion[0].pair.from + ' to ' + result[i].conversion[0].pair.to + '</a><br/><a href="#">' + result[i].conversion[1].pair.from + ' to ' + result[i].conversion[1].pair.to + '</a></td>' +
//                  
                    '<td class="exchange"><a href="'+link1+'" target="_blank"><img   src="http://cryptoscanner.co/images/c-logos/'+result[i].conversion[0].company+'.png"/></a><br/><a href="'+link2+'" target="_blank"><img src="http://cryptoscanner.co/images/c-logos/'+result[i].conversion[1].company+'.png"/></a></td>' +
                    '<td>' + result[i].conversion[0].rate + ' ' + result[i].conversion[0].rate_unit + '<br/>' + result[i].conversion[1].rate + ' ' + result[i].conversion[1].rate_unit + '</td>' +
                    '<td>' + result[i].conversion[0].unit_get + ' ' + result[i].conversion[0].pair.to + '<br/>' + result[i].conversion[1].unit_get + ' ' + result[i].conversion[1].pair.to + '</td>' +
                    '</tr>';
                     html += '<tr class="d-table-row d-md-none"><td colspan="3">';
                     html += '<button type="button" class="btn btn-toggle-exchange btn-danger">See Exchanges</button>';
                     html += '<div class="exchange-details"><div class="first-exchange"><p class="d-inline-block">1ST EXCHANGE</p><a class="d-inline-block" href="'+link1+'" target="_blank"><img   src="http://cryptoscanner.co/images/c-logos/'+result[i].conversion[0].company+'.png"/></a></div><div class="second-exchange"><p class="d-inline-block">2ND EXCHANGE</p><a class="d-inline-block" href="'+link2+'" target="_blank"><img src="http://cryptoscanner.co/images/c-logos/'+result[i].conversion[1].company+'.png"/></a></div></div>';
                     html += '</td></tr>';
                    
            } else {
                id = i + 1;
                border = '';
            }
//
//            html +=
//                '<tr>' +
//                '<td '+ border +'></td>' +
//                '<td '+ border +'></td>' +
//                '<td '+ border +'></td>' +
//                '<td '+ border +'></td>' +
//                '</tr>';
        }

        $('#price-table tbody').html(html);
        //alert($('#price-table tbody').position().top);
       // $('html, body').animate({scrollTop:$('#price-table tbody').position().top}, 'slow');
    }
</script>

</body>
</html>
