<?php
/**
 * Date: 23.01.18
 * Time: 14:00
 */

//$crypto = $_GET['crypto'];

ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);


$base = $_GET['base'];
$quote = $_GET['quote'];


function getTheBest(){

    $base = $_GET['base'];
    $quote = $_GET['quote'];

    $sql = "SELECT exchange, price,base, quote FROM `v28_crypto_ticker` WHERE `base` = '".$base."' and `quote` = '".$quote."' and price <> 0 and price is not NULL order by `price` asc limit 10 ";
    $data = array(
        'db_host'				    => 'localhost',
        'db_base'				    => 'prices',
        'db_user'				    => 'root',
        'db_pass'				    => 'NON4242(&&$2@@#342',
    );

    $mysqli = new mysqli($data['db_host'], $data['db_user'], $data['db_pass'], $data['db_base']);
    $mysqli->set_charset('utf8');

    $result = $mysqli->query($sql);

    $data = array();
    while ($item = $result->fetch_assoc()) {
        $data[] = array(
                'base'=>strtolower($item['base']),
                'quote'=>strtolower($item['quote']),
                'exchange'=>$item['exchange'],
                'price'=>$item['price']
        );
    }
    return $data;
}








function getSymbols(){

    $sql = "SELECT base, quote, count(id) FROM `v28_crypto_ticker` WHERE exchange <> ' coinmarketcap' and price <> 0 and price is not NULL GROUP BY base, quote HAVING count(id)>4 order by `price` desc limit 100 ";
    $data = array(
        'db_host'				    => 'localhost',
        'db_base'				    => 'prices',
        'db_user'				    => 'root',
        'db_pass'				    => 'NON4242(&&$2@@#342',
    );

    $mysqli = new mysqli($data['db_host'], $data['db_user'], $data['db_pass'], $data['db_base']);
    $mysqli->set_charset('utf8');

    $result = $mysqli->query($sql);

    $data = array();
    while ($item = $result->fetch_assoc()) {
        if (!$item['base']){continue;}
        $data[] = $item;

    }
    return $data;

}

$items = getTheBest();

$pairs = getSymbols();

?>

<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tickers</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

    <script src="//cdnjs.cloudflare.com/ajax/libs/list.js/1.5.0/list.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/socket.io/2.0.3/socket.io.js"></script>
</head>

<body>
<h1><?php echo $base.'/'.$quote; ?></h1>
    <div id="cryptolist">

        <ul class="list">
            <?php foreach ($items as $item) {?>
                <li>
                    <span class="value" id="<?php echo $item['exchange'].'_'.strtolower($item['base']).'_'.strtolower($item['quote']);?>"><?php echo $item['price'];?></span>
                    <span class="exchange"><?php echo $item['exchange'];?></span>
                </li>
            <?php } ?>
        </ul>

    </div>


<ul >
    <?php foreach ($pairs as $pair) {?>
        <li>
            <a href="index.php?base=<?php echo $pair['base'];?>&quote=<?php echo $pair['quote'];?>"><?php echo $pair['base'].'/'.$pair['quote'];?></a>
        </li>
    <?php } ?>
</ul>
<script>

</script>

<style>
    .value {
        font-size: 20px;
    }
    .exchange {
        padding: 11px;
    }
</style>

<script type="text/javascript">

    var socket = io.connect('https://coincap.io');

    <?php if ($quote == 'USD' or $quote == 'USDT') { ?>
        socket.on('trades', function (data) {
            updateMarkets(data);
        });
    <?php }?>

    var options = {valueNames: ['value', 'exchange']};

    var crList = {};

    window.updateMarkets = function (data) {

//        console.log(data);
        if (data.coin != undefined) {
            var coin = data.coin;

            if (data.coin == "<?php echo strtoupper($base);?>") {
                sel = $('#' + data.exchange_id + '_<?php echo strtolower($base).'_'.strtolower($quote);?>');

                if (sel.length) {
                    sel.html(data.msg.price);
                    crList = new List('cryptolist', options);
                    crList.sort('value', {order: "asc", sortFunction:function (a, b) {
                        return Number(a)>Number(b)
                    }} );
                }
            }
            price = data.msg.price;
        }

    };


    function update() {

        $.getJSON('update.php',{base:'<?php echo $base;?>',quote:'<?php echo $quote;?>'}, function (data) {

            $(".list li").each(function(index, value) {
                $(this).addClass('remove');
            });

            for (var i in data) {
                var row = data[i];
                id = row.exchange + '_'+row.base+'_'+row.quote;
                sel = $('#' + row.exchange + '_'+row.base+'_'+row.quote);
                if (sel.length){
                    sel.html(row.price).parent().removeClass('remove');
                } else {
                    $('.list').append(' <li><span class="value" id="'+id+'">'+row.price+'</span><span class="exchange">'+row.exchange+'</span></li>');
                }

            }
            $(".remove").each(function(index, value) {
                $(this).remove();
            });
            crList = new List('cryptolist', options);
            crList.sort('value', {order: "asc", sortFunction:function (a, b) {
                return Number(a)>Number(b)
            }} );
        });

    }

    update();

</script>

<style>
    .value {
        width: 200px;
    }
</style>
</body>
</html>
