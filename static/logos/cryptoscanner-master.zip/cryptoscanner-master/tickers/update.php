<?php
/**
 * Date: 29.01.18
 * Time: 4:12
 */

function getTheBest(){

    $base = $_GET['base'];
    $quote = $_GET['quote'];

    $sql = "SELECT exchange, price,base, quote FROM `v28_crypto_ticker` WHERE exchange <> ' coinmarketcap' and `base` = '".$base."' and `quote` = '".$quote."' and price <> 0 and price is not NULL order by `price` asc limit 10 ";
    $data = array(
        'db_host'				    => 'localhost',
        'db_base'				    => 'prices',
        'db_user'				    => 'root',
        'db_pass'				    => 'NON4242(&&$2@@#342',
    );

    $mysqli = new mysqli($data['db_host'], $data['db_user'], $data['db_pass'], $data['db_base']);
    $mysqli->set_charset('utf8');

    $result = $mysqli->query($sql);

    $data = array();
    while ($item = $result->fetch_assoc()) {
        $data[] = array(
            'base'=>strtolower($item['base']),
            'quote'=>strtolower($item['quote']),
            'exchange'=>$item['exchange'],
            'price'=>$item['price']
        );
    }
    return $data;

}

$items = getTheBest();


echo json_encode($items);