<?php
/**
 * Created by PhpStorm.
 * User: viacheslav
 * Date: 3/7/18
 * Time: 13:47
 */

class Currency {

    private $pdo;

    public function __construct($pdo)
    {
        $this->pdo = $pdo;
    }

    public function getAllNames()
    {
        $stmt = $this->pdo->query('SELECT * FROM currency');
        $stmt->execute();

        return $stmt->fetchAll();
    }
     public function formatdecimal($num)
	{
		
		if($num < 1)
		{
			$num = number_format($num, 8, '.', '');
			preg_match("/^(0+)/", explode('.', $num)[1], $matches);
			if($matches)
			{
				if(strlen($matches[0]) > 4)
				{
					$num = number_format($num, 8);
				}
				else if(strlen($matches[0]) == 2 && strlen($matches[0]) == 3)
				{
					$num = number_format($num, 6);
				}
				else 
				{
					$num = number_format($num, 5);
				}
			}
			
		}
		else
		{
			$num = number_format($num, 2);
		}
		
		return $num;
		
	}
    public function calc($amount, $from, $to)
    {
        $stmt = $this->pdo->prepare('SELECT id, exchange, symbol, base, quote, quote, bid, ask, price FROM v28_crypto_ticker WHERE (base = ? OR quote = ? OR base = ? OR quote = ?) AND price IS NOT NULL AND price != 0 AND price != "" AND exchange NOT IN ("coinmarketcap","ccex","southxchange","lykke","quoinex","coingi","qryptos","cryptopia","gatecoin","coinexchange","nova") AND base NOT IN ("DAT","CK.USD") AND quote NOT IN ("DAT","CK.USD")');
        $stmt->execute(array($to, $from, $from, $to));
        $data = $stmt->fetchAll();
        $rows = array();

        if ($data) {
            $rates = array();

            foreach ($data as $value) {
                
               
	                if (
	                        ($value['base'] == $to && $value['quote'] == $from) ||
	                        ($value['base'] == $from && $value['quote'] == $to))
	                {
	                    $rates['plain'][] = $value;
	                    continue;
	                }

	                if ($value['base'] == $from || $value['quote'] == $from) {
	                    $key = $value['base'] != $from ? $value['base'] : $value['quote'];
	                    $rates['over'][$key]['input'][] = $value;
	                }

	                if ($value['base'] == $to || $value['quote'] == $to) {
	                    $key = $value['base'] != $to ? $value['base'] : $value['quote'];
	                    $rates['over'][$key]['output'][] = $value;
	                }
	           
            }

            if ($rates) {
                if (!empty($rates['plain'])) {
                    foreach ($rates['plain'] as $plain) {
                       // $row = $this->getRowContent($from, $amount, $plain);
                      /*  $rows[] = array(
                            'amount'     => $row['amount'],
                            'conversion' => array($row)
                        );
                        */
                    }
                }

                 if (!empty($rates['over'])) {
                    foreach ($rates['over'] as $currency => $over) {
                        if (empty($over['input']) || empty($over['output'])) {
                            continue;
                        }

                        foreach ($over['input'] as $input) {
                            
                            //for input case
                            if($input['base'] == $from)
                            {
								$unit_get = $input['price'] * $amount;
								$rate = 1 / $input['price'];
								$rate = $this->formatdecimal($rate);
								$unit_get = $this->formatdecimal($unit_get);
								$rows_input = array(
								'rate'   => $rate,
								'rate_unit'   => $input['base'],
								'unit_get' => $unit_get,
								'pair'    => array(
								'from' => $input['base'],
								'to'   => $input['quote'],
								),
								'company' => $input['exchange'],
								);
							}
							else
							{
								
								$unit_get = (1 / $input['price']) * $amount;
								$rate = $input['price'];
								$rate = $this->formatdecimal($rate);
								$unit_get = $this->formatdecimal($unit_get);
								$rows_input = array(
								'rate'   => $rate,
								'rate_unit'   => $input['quote'],
								'unit_get' => $unit_get,
								'pair'    => array(
								'from' => $input['quote'],
								'to'   => $input['base'],
								),
								'company' => $input['exchange'],
								);
								
							}

                            $output = $over['output'];
							$randIndex = array_rand($output);
							$randoutput = $output[$randIndex];
							
							//for output case
                            if($randoutput['base'] == $to)
                            {
								$rate = $randoutput['price'];
								$unit_get = str_ireplace(',','',$unit_get);
								$output_unit_get = $unit_get / $rate;
								$rate = $this->formatdecimal($rate);
								$output_unit_get = $this->formatdecimal($output_unit_get);
								$rows_output = array(
								'rate'   => $rate,
								'rate_unit'   => $randoutput['quote'],
								'unit_get' => $output_unit_get,
								'pair'    => array(
								'from' => $randoutput['quote'],
								'to'   => $randoutput['base'],
								),
								'company' => $randoutput['exchange'],
								);
							}
							else
							{
								$rate = 1 / $randoutput['price'];
								$unit_get = str_ireplace(',','',$unit_get);
								$output_unit_get = $unit_get / $rate;
								$rate = $this->formatdecimal($rate);
								$output_unit_get = $this->formatdecimal($output_unit_get);
								$rows_output = array(
								'rate'   => $rate,
								'rate_unit'   => $randoutput['base'],
								'unit_get' => $output_unit_get,
								'pair'    => array(
								'from' => $randoutput['base'],
								'to'   => $randoutput['quote'],
								),
								'company' => $randoutput['exchange'],
								);
								
							}
                            
                            
                            $rows[] = array(
                                'amount' => $output_unit_get,
                                'conversion' => array($rows_input, $rows_output)
                            );
                            
                            
                        }
                    }
                }
            }

            function conversionSort($a, $b)
            {
                $a_amount = str_replace(',' ,'', $a['amount']);
                $b_amount = str_replace(',' ,'', $b['amount']);
                
                if ($a_amount == $b_amount) {
                    $result = 0;
                } else {
                    $result = $a_amount < $b_amount ? 1 : -1;
                }

                return $result;
            }

           uasort($rows, 'conversionSort');

            $rows = array_values($rows);
        }

        return $rows;
    }

    private function getRowContent($from, $amount, $value)
    {
//        if ($value['base'] == $from) {
//            $rows = array(
//                'price'   => $value['price'],
//                'amount' => $value['price'] * $amount,
//                'pair'    => array(
//                    'from' => $value['base'],
//                    'to'   => $value['quote'],
//                ),
//                'company' => $value['exchange'],
//            );
//        } else {
//            $price = 1 / $value['price'];
//            $rows = array(
//                'price'   => $price,
//                'amount' => $price * $amount,
//                'pair'    => array(
//                    'from' => $value['quote'],
//                    'to'   => $value['base'],
//                ),
//                'company' => $value['exchange'],
//            );
//        }

        if ($value['base'] == $from) {
            $price = 1 / $value['price'];
            $rows = array(
                'price'   => $price,
                'amount'  => $amount / $price,
                'pair'    => array(
                    'from' => $value['base'],
                    'to'   => $value['quote'],
                ),
                'company' => $value['exchange'],
            );
        } else {
            $rows = array(
                'price'   => $value['price'],
                'amount'  => $amount / $value['price'],
                'pair'    => array(
                    'from' => $value['quote'],
                    'to'   => $value['base'],
                ),
                'company' => $value['exchange'],
            );
        }

        return $rows;
    }
}