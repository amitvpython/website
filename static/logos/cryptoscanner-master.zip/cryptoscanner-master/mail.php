<?php
error_reporting(-1);
ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
$to = 'test@cryptoscanner.co';
$subject ="Query received at cryptoscanner.co";
$from = 'no-reply@cryptoscanner.co'; 
$message = "
Hi,<br/>
Below mentioned details have been received on http://cryptoscanner.co<br/>

<table>
<tr>
<td>Name: Bala</td>
</tr><tr>
<td>Email: bala121083@gmail.com</td>
</tr><tr>
<td>Subject: Crypto Scanner</td>
</tr><tr>
<td>Query: Testing Crypto Scanner</td>
</tr>
</table>
<br/>
Thanks,<br/>
Danial<br/>
cryptoscanner.co 
";

if(send_email($from, $to, $subject, $message)){
    //sent
    print_r(error_get_last());
}
else
{
	echo 'mail sent';
}

/*sending email using PHP mail function*/
function send_email($from ='',$to = '', $subject = '',$msg = '') 
{
    $message = '<html>';
    $message = ucfirst($msg);
    $message .= '</html>';
    // To send HTML mail, the Content-type header must be set
    $headers  = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    // Additional headers
    $headers .= 'From: '.$from.'' . "\r\n";
    $headers .= 'Cc: bala121083@gmail.com' . "\r\n";
    $headers .= 'Cc: test@cryptoscanner.co' . "\r\n";
    $ret = @mail($to, $subject,$message, $headers);
    return $ret;
}
         
   
