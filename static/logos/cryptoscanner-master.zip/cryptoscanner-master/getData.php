<?php
error_reporting(-1);
ini_set('display_errors', 1);
function dd($data)
{
    echo '<pre>';
    var_dump($data);
    echo '</pre>';
    die();
}

if (!empty($_POST['type'])) {
    $data = array();
    $host = 'localhost';
    $dbName = 'prices';
    $user = 'root';
    $password = 'NON4242(&&$2@@#342';
    $dbh = new PDO('mysql:host=' . $host . ';dbname=' . $dbName, $user, $password, array(
        PDO::ATTR_PERSISTENT         => true,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ));

    require_once 'Currency.php';
    $currencyObject = new Currency($dbh);

    switch ($_POST['type']) {
        case 'getAllCurrencyNames':
            $data['result'] = $currencyObject->getAllNames();
            break;
        case 'calc':
            $to = !empty($_POST['toCurrency']) ? $_POST['toCurrency'] : '';
            $from = !empty($_POST['fromCurrency']) ? $_POST['fromCurrency'] : '';
            $data['result'] = $currencyObject->calc($_POST['amount'], $from, $to);
            break;
    }

    header('Content-type: application/json');
    echo json_encode($data);
    exit;
}



